create procedure gggg()
  BEGIN
	 declare i int;
    set i=1;
    while i<21 do
        insert INTO admin(`username`,`avater`,`PASSWORD`,`role`,`description`,`age`,`phone`) values(concat('admin',i),'/images/林心如.jpeg','123'+i,'超级管理员','超级管理员',i,1533695403);
        set i=i+1;
     end while;
END;

